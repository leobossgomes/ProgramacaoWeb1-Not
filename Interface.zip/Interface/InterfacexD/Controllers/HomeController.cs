﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using InterfacexD.Models;
using Newtonsoft.Json;
using FluentAssertions.Common;

namespace InterfacexD.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult buscarDados()
        {
            return Json(BancoDeDados.TodosOsObjetos);
        }

        public void AtualizarPosicao([FromBody] object objeto)
        {
            Objeto objetoAtualizado = null;

            if (System.Text.RegularExpressions.Regex.IsMatch(objeto.ToString(), "\"R\""))
                objetoAtualizado = JsonConvert.DeserializeObject<Robo>(objeto.ToString());
            else
                objetoAtualizado = JsonConvert.DeserializeObject<Estante>(objeto.ToString());

            BancoDeDados.TodosOsObjetos.Where(r => r.ID == objetoAtualizado.ID && r.RepresentacaoVisual == objetoAtualizado.RepresentacaoVisual).FirstOrDefault().PosicaoX = objetoAtualizado.PosicaoX;
            BancoDeDados.TodosOsObjetos.Where(r => r.ID == objetoAtualizado.ID && r.RepresentacaoVisual == objetoAtualizado.RepresentacaoVisual).FirstOrDefault().PosicaoY = objetoAtualizado.PosicaoY;
        }
    }
}
