﻿namespace InterfacexD.Models {
    public class Estante : Objeto {
        public override string RepresentacaoVisual { get { return "E"; } }

        public Estante(int id, int posicaoX, int posicaoY) : base(id, posicaoX, posicaoY) { }
    }
}
