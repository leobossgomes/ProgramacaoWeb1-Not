﻿namespace InterfacexD.Models
{

    public abstract class Objeto
    {
        public abstract string RepresentacaoVisual { get; }
        public long ID { get; protected set; }
        public int PosicaoX { get; set; }
        public int PosicaoY { get; set; }
        public int PosicaoXInicial { get; set; }
        public int PosicaoYInicial { get; set; }

        public Objeto(int id, int posicaoX, int posicaoY)
        {
            PosicaoX = posicaoX;
            PosicaoY = posicaoY;
            PosicaoXInicial = posicaoX;
            PosicaoYInicial = posicaoY;
            ID = id;
        }
    }
}
